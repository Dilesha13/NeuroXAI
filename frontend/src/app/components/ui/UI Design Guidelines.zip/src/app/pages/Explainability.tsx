import { Brain, Info, TrendingUp, Zap } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Progress } from '../components/ui/progress';
import { Badge } from '../components/ui/badge';

const channelImportance = [
  { channel: 'FP1', importance: 92, color: 'bg-red-500' },
  { channel: 'FP2', importance: 89, color: 'bg-orange-500' },
  { channel: 'C3', importance: 78, color: 'bg-yellow-500' },
  { channel: 'C4', importance: 75, color: 'bg-green-500' },
  { channel: 'O1', importance: 64, color: 'bg-blue-500' },
  { channel: 'O2', importance: 61, color: 'bg-purple-500' },
];

const temporalAttention = [
  { timeWindow: '0-5 min', attention: 15 },
  { timeWindow: '5-10 min', attention: 22 },
  { timeWindow: '10-15 min', attention: 38 },
  { timeWindow: '15-20 min', attention: 72 },
  { timeWindow: '20-25 min', attention: 95 },
  { timeWindow: '25-30 min', attention: 98 },
  { timeWindow: '30-35 min', attention: 87 },
  { timeWindow: '35-40 min', attention: 54 },
  { timeWindow: '40-45 min', attention: 28 },
];

export default function Explainability() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Explainable AI Analysis</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Understanding how the AI model made its prediction for Patient PT-1247
        </p>
      </div>

      {/* Info Banner */}
      <Card className="dark:bg-slate-800 dark:border-gray-700 bg-blue-50 dark:bg-blue-900/20 border-blue-200 dark:border-blue-800">
        <CardContent className="p-6">
          <div className="flex gap-3">
            <Info className="h-5 w-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
            <div>
              <p className="font-semibold text-blue-900 dark:text-blue-200 mb-1">
                What is Explainable AI?
              </p>
              <p className="text-sm text-blue-800 dark:text-blue-300">
                These visualizations show which EEG signal segments and channels most influenced the AI model's 
                prediction. Highlighted regions indicate areas of high importance in the seizure detection decision.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Saliency Heatmap */}
      <Card className="dark:bg-slate-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white flex items-center gap-2">
            <Zap className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
            EEG Saliency Heatmap
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <p className="text-sm text-gray-600 dark:text-gray-400">
            Highlighted regions indicate EEG signal segments that most influenced the AI model's seizure detection.
          </p>
          
          {/* Heatmap Visualization */}
          <div className="bg-gray-900 dark:bg-black rounded-lg p-6 overflow-x-auto">
            <div className="min-w-[600px]">
              {channelImportance.map((channel, idx) => (
                <div key={channel.channel} className="mb-4">
                  <div className="flex items-center gap-3 mb-2">
                    <span className="text-xs font-mono text-gray-400 w-12">{channel.channel}</span>
                    <div className="flex-1 h-12 bg-gray-800 rounded relative overflow-hidden">
                      {/* Background wave pattern */}
                      <svg className="w-full h-full absolute inset-0" preserveAspectRatio="none" viewBox="0 0 100 20">
                        <path
                          d={`M 0 10 Q 10 ${8 + idx}, 20 10 T 40 10 Q 50 ${12 - idx}, 60 10 T 80 10 Q 90 ${9 + idx}, 100 10`}
                          stroke="#4B5563"
                          strokeWidth="1"
                          fill="none"
                        />
                      </svg>
                      
                      {/* Attention overlay - highest between 20-35% */}
                      <div className="absolute inset-y-0 left-[20%] right-[65%] bg-gradient-to-r from-transparent via-red-500/50 to-transparent" />
                      <div className="absolute inset-y-0 left-[35%] right-[50%] bg-gradient-to-r from-transparent via-yellow-500/40 to-transparent" />
                    </div>
                  </div>
                </div>
              ))}
            </div>
            
            {/* Time markers */}
            <div className="flex justify-between text-xs text-gray-500 mt-2 ml-14">
              <span>0 min</span>
              <span>15 min</span>
              <span>30 min</span>
              <span>45 min</span>
            </div>
          </div>

          {/* Legend */}
          <div className="flex items-center gap-6 p-4 bg-gray-50 dark:bg-slate-900 rounded-lg">
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-red-500 rounded" />
              <span className="text-sm text-gray-700 dark:text-gray-300">High Importance</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-yellow-500 rounded" />
              <span className="text-sm text-gray-700 dark:text-gray-300">Medium Importance</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="w-4 h-4 bg-gray-600 rounded" />
              <span className="text-sm text-gray-700 dark:text-gray-300">Low Importance</span>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Channel Importance and Temporal Attention */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Top Important EEG Channels */}
        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-gray-900 dark:text-white flex items-center gap-2">
              <Brain className="h-5 w-5 text-purple-600 dark:text-purple-400" />
              Top Important EEG Channels
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {channelImportance.map((channel, idx) => (
              <div key={channel.channel}>
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-3">
                    <Badge variant="outline" className="font-mono dark:border-gray-600">
                      {channel.channel}
                    </Badge>
                    <span className="text-sm text-gray-600 dark:text-gray-400">
                      {idx === 0 ? 'Frontal Left' : 
                       idx === 1 ? 'Frontal Right' : 
                       idx === 2 ? 'Central Left' :
                       idx === 3 ? 'Central Right' :
                       idx === 4 ? 'Occipital Left' : 'Occipital Right'}
                    </span>
                  </div>
                  <span className="font-semibold text-gray-900 dark:text-white">{channel.importance}%</span>
                </div>
                <Progress value={channel.importance} className="h-2" />
              </div>
            ))}
            <div className="mt-6 p-4 bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg">
              <p className="text-sm text-purple-800 dark:text-purple-200">
                The frontal channels (FP1, FP2) showed the strongest indicators of seizure activity, 
                contributing most significantly to the model's prediction.
              </p>
            </div>
          </CardContent>
        </Card>

        {/* Temporal Attention Map */}
        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-gray-900 dark:text-white flex items-center gap-2">
              <TrendingUp className="h-5 w-5 text-teal-600 dark:text-teal-400" />
              Temporal Attention Map
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            {temporalAttention.map((segment) => (
              <div key={segment.timeWindow}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-900 dark:text-white">
                    {segment.timeWindow}
                  </span>
                  <span className="text-sm font-semibold text-gray-900 dark:text-white">
                    {segment.attention}%
                  </span>
                </div>
                <div className="relative">
                  <Progress value={segment.attention} className="h-2" />
                  {segment.attention > 80 && (
                    <div className="absolute -right-1 -top-1">
                      <div className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />
                    </div>
                  )}
                </div>
              </div>
            ))}
            <div className="mt-6 p-4 bg-teal-50 dark:bg-teal-900/20 border border-teal-200 dark:border-teal-800 rounded-lg">
              <p className="text-sm text-teal-800 dark:text-teal-200">
                The model focused most heavily on the 25-30 minute window, where seizure patterns 
                were most pronounced and consistent across multiple channels.
              </p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Clinical Notes */}
      <Card className="dark:bg-slate-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white">Clinical Decision Support Notes</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="prose dark:prose-invert max-w-none">
            <div className="space-y-4 text-gray-700 dark:text-gray-300">
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Key Findings:</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>Strong bilateral frontal lobe seizure activity detected (FP1, FP2 channels)</li>
                  <li>Peak seizure event occurred at approximately 25-30 minutes into recording</li>
                  <li>Sustained abnormal activity observed for ~15 minute duration</li>
                  <li>All monitored channels showed synchronized abnormal patterns during peak event</li>
                </ul>
              </div>
              
              <div>
                <h4 className="font-semibold text-gray-900 dark:text-white mb-2">Model Confidence Factors:</h4>
                <ul className="list-disc list-inside space-y-1 text-sm">
                  <li>High inter-channel correlation during seizure event (supporting evidence)</li>
                  <li>Characteristic frequency patterns matching known neonatal seizure signatures</li>
                  <li>Clear temporal evolution of seizure activity with defined onset and offset</li>
                  <li>Amplitude and morphology consistent with clinical seizure criteria</li>
                </ul>
              </div>

              <div className="p-4 bg-amber-50 dark:bg-amber-900/20 border border-amber-200 dark:border-amber-800 rounded-lg">
                <p className="text-sm text-amber-900 dark:text-amber-200">
                  <strong>Clinical Recommendation:</strong> These AI insights are intended to support, not replace, 
                  clinical judgment. Please review the raw EEG data and consider the clinical context when making 
                  diagnostic and treatment decisions.
                </p>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
