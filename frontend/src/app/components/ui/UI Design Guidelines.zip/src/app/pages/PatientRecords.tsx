import { useState } from 'react';
import { Search, Filter, Download, Eye, ChevronLeft, ChevronRight } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Button } from '../components/ui/button';
import { Badge } from '../components/ui/badge';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '../components/ui/select';
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from '../components/ui/table';

const patientData = [
  {
    id: 'PT-1247',
    date: '2026-03-15 09:23',
    duration: '45 min',
    status: 'Seizure Detected',
    confidence: '94%',
    result: 'Abnormal',
    statusColor: 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200',
  },
  {
    id: 'PT-1246',
    date: '2026-03-15 08:15',
    duration: '60 min',
    status: 'Normal',
    confidence: '98%',
    result: 'Normal',
    statusColor: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200',
  },
  {
    id: 'PT-1245',
    date: '2026-03-14 22:45',
    duration: '30 min',
    status: 'Normal',
    confidence: '96%',
    result: 'Normal',
    statusColor: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200',
  },
  {
    id: 'PT-1244',
    date: '2026-03-14 18:30',
    duration: '40 min',
    status: 'Seizure Detected',
    confidence: '91%',
    result: 'Abnormal',
    statusColor: 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200',
  },
  {
    id: 'PT-1243',
    date: '2026-03-14 14:20',
    duration: '55 min',
    status: 'Normal',
    confidence: '99%',
    result: 'Normal',
    statusColor: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200',
  },
  {
    id: 'PT-1242',
    date: '2026-03-14 10:15',
    duration: '35 min',
    status: 'Normal',
    confidence: '97%',
    result: 'Normal',
    statusColor: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200',
  },
  {
    id: 'PT-1241',
    date: '2026-03-13 16:45',
    duration: '50 min',
    status: 'Seizure Detected',
    confidence: '89%',
    result: 'Abnormal',
    statusColor: 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200',
  },
  {
    id: 'PT-1240',
    date: '2026-03-13 12:30',
    duration: '42 min',
    status: 'Normal',
    confidence: '95%',
    result: 'Normal',
    statusColor: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200',
  },
];

export default function PatientRecords() {
  const [searchQuery, setSearchQuery] = useState('');
  const [filterStatus, setFilterStatus] = useState('all');
  const [currentPage, setCurrentPage] = useState(1);
  const itemsPerPage = 10;

  const filteredData = patientData.filter((record) => {
    const matchesSearch = record.id.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesFilter = filterStatus === 'all' || 
      (filterStatus === 'seizure' && record.result === 'Abnormal') ||
      (filterStatus === 'normal' && record.result === 'Normal');
    return matchesSearch && matchesFilter;
  });

  const totalPages = Math.ceil(filteredData.length / itemsPerPage);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Patient Records</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Comprehensive EEG analysis history and patient data
        </p>
      </div>

      {/* Filters and Search */}
      <Card className="dark:bg-slate-800 dark:border-gray-700">
        <CardContent className="p-6">
          <div className="flex flex-col sm:flex-row gap-4">
            {/* Search */}
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-gray-400" />
              <Input
                type="text"
                placeholder="Search by Patient ID..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-10 dark:bg-slate-900 dark:border-gray-700"
              />
            </div>

            {/* Filter by Status */}
            <div className="w-full sm:w-48">
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger className="dark:bg-slate-900 dark:border-gray-700">
                  <Filter className="h-4 w-4 mr-2" />
                  <SelectValue placeholder="Filter by status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All Records</SelectItem>
                  <SelectItem value="seizure">Seizure Detected</SelectItem>
                  <SelectItem value="normal">Normal</SelectItem>
                </SelectContent>
              </Select>
            </div>

            {/* Export */}
            <Button variant="outline" className="dark:border-gray-700">
              <Download className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Desktop Table */}
      <Card className="dark:bg-slate-800 dark:border-gray-700 hidden md:block">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white">Analysis Records</CardTitle>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow className="dark:border-gray-700">
                <TableHead className="text-gray-900 dark:text-gray-300">Patient ID</TableHead>
                <TableHead className="text-gray-900 dark:text-gray-300">Recording Date</TableHead>
                <TableHead className="text-gray-900 dark:text-gray-300">Duration</TableHead>
                <TableHead className="text-gray-900 dark:text-gray-300">Status</TableHead>
                <TableHead className="text-gray-900 dark:text-gray-300">Confidence</TableHead>
                <TableHead className="text-gray-900 dark:text-gray-300">Result</TableHead>
                <TableHead className="text-gray-900 dark:text-gray-300">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredData.map((record) => (
                <TableRow key={record.id} className="dark:border-gray-700">
                  <TableCell className="font-medium text-gray-900 dark:text-white">
                    {record.id}
                  </TableCell>
                  <TableCell className="text-gray-600 dark:text-gray-400">{record.date}</TableCell>
                  <TableCell className="text-gray-600 dark:text-gray-400">{record.duration}</TableCell>
                  <TableCell>
                    <Badge className={record.statusColor}>{record.status}</Badge>
                  </TableCell>
                  <TableCell className="font-medium text-gray-900 dark:text-white">
                    {record.confidence}
                  </TableCell>
                  <TableCell className="text-gray-600 dark:text-gray-400">{record.result}</TableCell>
                  <TableCell>
                    <div className="flex gap-2">
                      <Button variant="ghost" size="sm" className="dark:hover:bg-slate-700">
                        <Eye className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="sm" className="dark:hover:bg-slate-700">
                        <Download className="h-4 w-4" />
                      </Button>
                    </div>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      {/* Mobile Cards */}
      <div className="md:hidden space-y-4">
        {filteredData.map((record) => (
          <Card key={record.id} className="dark:bg-slate-800 dark:border-gray-700">
            <CardContent className="p-4">
              <div className="flex items-center justify-between mb-3">
                <p className="font-semibold text-gray-900 dark:text-white">{record.id}</p>
                <Badge className={record.statusColor}>{record.status}</Badge>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Date:</span>
                  <span className="text-gray-900 dark:text-white">{record.date}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Duration:</span>
                  <span className="text-gray-900 dark:text-white">{record.duration}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600 dark:text-gray-400">Confidence:</span>
                  <span className="font-medium text-gray-900 dark:text-white">{record.confidence}</span>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button variant="outline" size="sm" className="flex-1 dark:border-gray-700">
                  <Eye className="h-4 w-4 mr-2" />
                  View
                </Button>
                <Button variant="outline" size="sm" className="flex-1 dark:border-gray-700">
                  <Download className="h-4 w-4 mr-2" />
                  Export
                </Button>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Pagination */}
      <Card className="dark:bg-slate-800 dark:border-gray-700">
        <CardContent className="p-4">
          <div className="flex items-center justify-between">
            <p className="text-sm text-gray-600 dark:text-gray-400">
              Showing {filteredData.length} of {patientData.length} records
            </p>
            <div className="flex items-center gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((prev) => Math.max(1, prev - 1))}
                disabled={currentPage === 1}
                className="dark:border-gray-700"
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="text-sm text-gray-600 dark:text-gray-400">
                Page {currentPage} of {totalPages}
              </span>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setCurrentPage((prev) => Math.min(totalPages, prev + 1))}
                disabled={currentPage === totalPages}
                className="dark:border-gray-700"
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
