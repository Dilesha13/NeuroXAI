import { AlertCircle, CheckCircle, Activity, Clock, TrendingUp } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import { Progress } from '../components/ui/progress';
import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Area,
  AreaChart,
} from 'recharts';

const seizureTimeline = [
  { time: '0', probability: 0.12 },
  { time: '5', probability: 0.15 },
  { time: '10', probability: 0.18 },
  { time: '15', probability: 0.45 },
  { time: '20', probability: 0.78 },
  { time: '25', probability: 0.92 },
  { time: '30', probability: 0.94 },
  { time: '35', probability: 0.89 },
  { time: '40', probability: 0.65 },
  { time: '45', probability: 0.32 },
];

const eegChannels = [
  { time: 0, fp1: 45, fp2: 52, c3: 38, c4: 42, o1: 35, o2: 40 },
  { time: 5, fp1: 48, fp2: 55, c3: 41, c4: 45, o1: 38, o2: 43 },
  { time: 10, fp1: 52, fp2: 58, c3: 45, c4: 48, o1: 42, o2: 46 },
  { time: 15, fp1: 65, fp2: 72, c3: 58, c4: 62, o1: 55, o2: 59 },
  { time: 20, fp1: 85, fp2: 92, c3: 78, c4: 82, o1: 75, o2: 79 },
  { time: 25, fp1: 95, fp2: 98, c3: 88, c4: 92, o1: 85, o2: 89 },
  { time: 30, fp1: 92, fp2: 95, c3: 85, c4: 89, o1: 82, o2: 86 },
  { time: 35, fp1: 78, fp2: 82, c3: 71, c4: 75, o1: 68, o2: 72 },
  { time: 40, fp1: 58, fp2: 62, c3: 51, c4: 55, o1: 48, o2: 52 },
  { time: 45, fp1: 42, fp2: 46, c3: 35, c4: 39, o1: 32, o2: 36 },
];

export default function AIAnalysis() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">AI Analysis Results</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Detailed analysis output for Patient PT-1247
        </p>
      </div>

      {/* Patient Information */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-blue-100 dark:bg-blue-900 rounded-lg">
                <Activity className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Patient ID</p>
                <p className="text-xl font-bold text-gray-900 dark:text-white">PT-1247</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-purple-100 dark:bg-purple-900 rounded-lg">
                <Clock className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Duration</p>
                <p className="text-xl font-bold text-gray-900 dark:text-white">45 minutes</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardContent className="p-6">
            <div className="flex items-center gap-3">
              <div className="p-3 bg-teal-100 dark:bg-teal-900 rounded-lg">
                <TrendingUp className="h-6 w-6 text-teal-600 dark:text-teal-400" />
              </div>
              <div>
                <p className="text-sm text-gray-600 dark:text-gray-400">Analysis Time</p>
                <p className="text-xl font-bold text-gray-900 dark:text-white">2026-03-15 09:23</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Prediction Result */}
      <Card className="dark:bg-slate-800 dark:border-gray-700 border-2 border-red-200 dark:border-red-900">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white flex items-center gap-3">
            <AlertCircle className="h-6 w-6 text-red-600 dark:text-red-400" />
            Prediction Result
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Status</p>
              <Badge className="bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200 text-lg px-4 py-2">
                Seizure Detected
              </Badge>
            </div>
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Probability Score</p>
              <p className="text-3xl font-bold text-red-600 dark:text-red-400">94.2%</p>
            </div>
            <div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Confidence Level</p>
              <div className="space-y-2">
                <Progress value={94} className="h-3" />
                <p className="text-sm font-semibold text-gray-900 dark:text-white">Very High Confidence</p>
              </div>
            </div>
          </div>

          <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
            <p className="text-sm text-red-800 dark:text-red-200">
              <strong>Clinical Alert:</strong> This EEG recording shows strong indicators of neonatal seizure activity. 
              Immediate clinical review and intervention is recommended. Please consult with a neurologist for comprehensive evaluation.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Seizure Detection Timeline */}
      <Card className="dark:bg-slate-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white">Seizure Detection Timeline</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={300}>
            <AreaChart data={seizureTimeline}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-gray-300 dark:stroke-gray-700" />
              <XAxis
                dataKey="time"
                label={{ value: 'Time (minutes)', position: 'insideBottom', offset: -5 }}
                className="text-gray-600 dark:text-gray-400"
              />
              <YAxis
                label={{ value: 'Seizure Probability', angle: -90, position: 'insideLeft' }}
                className="text-gray-600 dark:text-gray-400"
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                }}
                formatter={(value: number) => `${(value * 100).toFixed(1)}%`}
              />
              <Area
                type="monotone"
                dataKey="probability"
                stroke="#EF4444"
                fill="#EF4444"
                fillOpacity={0.3}
                strokeWidth={2}
              />
            </AreaChart>
          </ResponsiveContainer>
          <div className="mt-4 p-3 bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg">
            <p className="text-sm text-yellow-800 dark:text-yellow-200">
              Peak seizure activity detected between minutes 20-35 with probability exceeding 90%
            </p>
          </div>
        </CardContent>
      </Card>

      {/* EEG Waveform Visualization */}
      <Card className="dark:bg-slate-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white">EEG Channel Activity</CardTitle>
        </CardHeader>
        <CardContent>
          <ResponsiveContainer width="100%" height={350}>
            <LineChart data={eegChannels}>
              <CartesianGrid strokeDasharray="3 3" className="stroke-gray-300 dark:stroke-gray-700" />
              <XAxis
                dataKey="time"
                label={{ value: 'Time (minutes)', position: 'insideBottom', offset: -5 }}
                className="text-gray-600 dark:text-gray-400"
              />
              <YAxis
                label={{ value: 'Amplitude (μV)', angle: -90, position: 'insideLeft' }}
                className="text-gray-600 dark:text-gray-400"
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: 'rgba(255, 255, 255, 0.95)',
                  border: '1px solid #e5e7eb',
                  borderRadius: '8px',
                }}
              />
              <Line type="monotone" dataKey="fp1" stroke="#3B82F6" strokeWidth={2} dot={false} name="FP1" />
              <Line type="monotone" dataKey="fp2" stroke="#8B5CF6" strokeWidth={2} dot={false} name="FP2" />
              <Line type="monotone" dataKey="c3" stroke="#10B981" strokeWidth={2} dot={false} name="C3" />
              <Line type="monotone" dataKey="c4" stroke="#14B8A6" strokeWidth={2} dot={false} name="C4" />
              <Line type="monotone" dataKey="o1" stroke="#F59E0B" strokeWidth={2} dot={false} name="O1" />
              <Line type="monotone" dataKey="o2" stroke="#EF4444" strokeWidth={2} dot={false} name="O2" />
            </LineChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>

      {/* Summary Metrics */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardContent className="p-6">
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Peak Seizure Time</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">25 min</p>
          </CardContent>
        </Card>
        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardContent className="p-6">
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Duration of Event</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">15 min</p>
          </CardContent>
        </Card>
        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardContent className="p-6">
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Affected Channels</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">6 / 6</p>
          </CardContent>
        </Card>
        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardContent className="p-6">
            <p className="text-sm text-gray-600 dark:text-gray-400 mb-1">Model Version</p>
            <p className="text-2xl font-bold text-gray-900 dark:text-white">v2.3.1</p>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
