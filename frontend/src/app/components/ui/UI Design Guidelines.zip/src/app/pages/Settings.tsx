import { useState } from 'react';
import { User, Lock, Bell, Palette, FileDown, Save } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Button } from '../components/ui/button';
import { Switch } from '../components/ui/switch';
import { Separator } from '../components/ui/separator';
import { useTheme } from '../context/ThemeContext';

export default function Settings() {
  const { theme, toggleTheme } = useTheme();
  const [profile, setProfile] = useState({
    fullName: 'Dr. Jane Smith',
    email: 'jane.smith@hospital.com',
    hospital: 'City General Hospital',
    specialization: 'Neonatal Neurology',
  });

  const [notifications, setNotifications] = useState({
    emailAlerts: true,
    seizureDetection: true,
    weeklyReports: false,
    systemUpdates: true,
  });

  const handleProfileChange = (field: string, value: string) => {
    setProfile(prev => ({ ...prev, [field]: value }));
  };

  const handleNotificationChange = (field: string, value: boolean) => {
    setNotifications(prev => ({ ...prev, [field]: value }));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Settings</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Manage your account and application preferences
        </p>
      </div>

      {/* User Profile */}
      <Card className="dark:bg-slate-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white flex items-center gap-2">
            <User className="h-5 w-5 text-blue-600 dark:text-teal-400" />
            User Profile
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center gap-6">
            <div className="w-24 h-24 bg-blue-100 dark:bg-blue-900 rounded-full flex items-center justify-center">
              <User className="h-12 w-12 text-blue-600 dark:text-blue-400" />
            </div>
            <div>
              <Button variant="outline" className="dark:border-gray-700">
                Change Photo
              </Button>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                JPG, PNG or GIF. Max size 2MB
              </p>
            </div>
          </div>

          <Separator className="dark:bg-gray-700" />

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div>
              <Label htmlFor="fullName" className="text-gray-700 dark:text-gray-300">Full Name</Label>
              <Input
                id="fullName"
                type="text"
                value={profile.fullName}
                onChange={(e) => handleProfileChange('fullName', e.target.value)}
                className="mt-1 dark:bg-slate-900 dark:border-gray-700"
              />
            </div>

            <div>
              <Label htmlFor="email" className="text-gray-700 dark:text-gray-300">Email Address</Label>
              <Input
                id="email"
                type="email"
                value={profile.email}
                onChange={(e) => handleProfileChange('email', e.target.value)}
                className="mt-1 dark:bg-slate-900 dark:border-gray-700"
              />
            </div>

            <div>
              <Label htmlFor="hospital" className="text-gray-700 dark:text-gray-300">Hospital / Organization</Label>
              <Input
                id="hospital"
                type="text"
                value={profile.hospital}
                onChange={(e) => handleProfileChange('hospital', e.target.value)}
                className="mt-1 dark:bg-slate-900 dark:border-gray-700"
              />
            </div>

            <div>
              <Label htmlFor="specialization" className="text-gray-700 dark:text-gray-300">Specialization</Label>
              <Input
                id="specialization"
                type="text"
                value={profile.specialization}
                onChange={(e) => handleProfileChange('specialization', e.target.value)}
                className="mt-1 dark:bg-slate-900 dark:border-gray-700"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <Button className="bg-blue-600 hover:bg-blue-700 dark:bg-teal-600 dark:hover:bg-teal-700 text-white">
              <Save className="h-4 w-4 mr-2" />
              Save Changes
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Security */}
      <Card className="dark:bg-slate-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white flex items-center gap-2">
            <Lock className="h-5 w-5 text-purple-600 dark:text-purple-400" />
            Security
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <Label htmlFor="currentPassword" className="text-gray-700 dark:text-gray-300">Current Password</Label>
            <Input
              id="currentPassword"
              type="password"
              placeholder="••••••••"
              className="mt-1 dark:bg-slate-900 dark:border-gray-700"
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <Label htmlFor="newPassword" className="text-gray-700 dark:text-gray-300">New Password</Label>
              <Input
                id="newPassword"
                type="password"
                placeholder="••••••••"
                className="mt-1 dark:bg-slate-900 dark:border-gray-700"
              />
            </div>

            <div>
              <Label htmlFor="confirmPassword" className="text-gray-700 dark:text-gray-300">Confirm Password</Label>
              <Input
                id="confirmPassword"
                type="password"
                placeholder="••••••••"
                className="mt-1 dark:bg-slate-900 dark:border-gray-700"
              />
            </div>
          </div>

          <div className="flex justify-end">
            <Button className="bg-purple-600 hover:bg-purple-700 dark:bg-purple-600 dark:hover:bg-purple-700 text-white">
              Update Password
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card className="dark:bg-slate-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white flex items-center gap-2">
            <Bell className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
            Notification Preferences
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-white">Email Alerts</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Receive important notifications via email
              </p>
            </div>
            <Switch
              checked={notifications.emailAlerts}
              onCheckedChange={(checked) => handleNotificationChange('emailAlerts', checked)}
            />
          </div>

          <Separator className="dark:bg-gray-700" />

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-white">Seizure Detection Alerts</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get notified immediately when seizures are detected
              </p>
            </div>
            <Switch
              checked={notifications.seizureDetection}
              onCheckedChange={(checked) => handleNotificationChange('seizureDetection', checked)}
            />
          </div>

          <Separator className="dark:bg-gray-700" />

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-white">Weekly Reports</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Receive weekly summary of analysis activities
              </p>
            </div>
            <Switch
              checked={notifications.weeklyReports}
              onCheckedChange={(checked) => handleNotificationChange('weeklyReports', checked)}
            />
          </div>

          <Separator className="dark:bg-gray-700" />

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-white">System Updates</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Get notified about new features and improvements
              </p>
            </div>
            <Switch
              checked={notifications.systemUpdates}
              onCheckedChange={(checked) => handleNotificationChange('systemUpdates', checked)}
            />
          </div>
        </CardContent>
      </Card>

      {/* App Settings */}
      <Card className="dark:bg-slate-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white flex items-center gap-2">
            <Palette className="h-5 w-5 text-teal-600 dark:text-teal-400" />
            App Settings
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-white">Theme Preference</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Current theme: {theme === 'light' ? 'Light Mode' : 'Dark Mode'}
              </p>
            </div>
            <Button
              variant="outline"
              onClick={toggleTheme}
              className="dark:border-gray-700"
            >
              Switch to {theme === 'light' ? 'Dark' : 'Light'} Mode
            </Button>
          </div>

          <Separator className="dark:bg-gray-700" />

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-white">Export Format</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Default format for exported reports
              </p>
            </div>
            <select className="px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-white">
              <option>PDF</option>
              <option>CSV</option>
              <option>JSON</option>
            </select>
          </div>

          <Separator className="dark:bg-gray-700" />

          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-white">Data Retention</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                How long to keep analysis data
              </p>
            </div>
            <select className="px-4 py-2 border border-gray-300 dark:border-gray-700 rounded-lg bg-white dark:bg-slate-900 text-gray-900 dark:text-white">
              <option>3 months</option>
              <option>6 months</option>
              <option>1 year</option>
              <option>Forever</option>
            </select>
          </div>
        </CardContent>
      </Card>

      {/* Data Management */}
      <Card className="dark:bg-slate-800 dark:border-gray-700">
        <CardHeader>
          <CardTitle className="text-gray-900 dark:text-white flex items-center gap-2">
            <FileDown className="h-5 w-5 text-green-600 dark:text-green-400" />
            Data Management
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900 dark:text-white">Export All Data</p>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Download all your patient records and analysis data
              </p>
            </div>
            <Button variant="outline" className="dark:border-gray-700">
              <FileDown className="h-4 w-4 mr-2" />
              Export
            </Button>
          </div>

          <Separator className="dark:bg-gray-700" />

          <div className="p-4 bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg">
            <p className="font-semibold text-red-900 dark:text-red-200 mb-2">Danger Zone</p>
            <p className="text-sm text-red-800 dark:text-red-300 mb-3">
              Deleting your account will permanently remove all data and cannot be undone.
            </p>
            <Button variant="destructive" size="sm">
              Delete Account
            </Button>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
