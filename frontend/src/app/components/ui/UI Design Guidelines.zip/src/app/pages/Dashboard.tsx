import { Activity, Users, FileCheck, Clock, TrendingUp, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Badge } from '../components/ui/badge';
import {
  LineChart,
  Line,
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from 'recharts';

const stats = [
  {
    title: 'Total EEG Analyses',
    value: '1,247',
    change: '+12%',
    trend: 'up',
    icon: Activity,
    color: 'text-blue-600 dark:text-blue-400',
    bgColor: 'bg-blue-100 dark:bg-blue-900',
  },
  {
    title: 'Seizure Detections',
    value: '89',
    change: '+8%',
    trend: 'up',
    icon: AlertCircle,
    color: 'text-red-600 dark:text-red-400',
    bgColor: 'bg-red-100 dark:bg-red-900',
  },
  {
    title: 'Normal Recordings',
    value: '1,158',
    change: '+11%',
    trend: 'up',
    icon: FileCheck,
    color: 'text-green-600 dark:text-green-400',
    bgColor: 'bg-green-100 dark:bg-green-900',
  },
  {
    title: 'Active Patients',
    value: '342',
    change: '+5%',
    trend: 'up',
    icon: Users,
    color: 'text-purple-600 dark:text-purple-400',
    bgColor: 'bg-purple-100 dark:bg-purple-900',
  },
];

const seizureTrends = [
  { month: 'Jan', detections: 12, normal: 98 },
  { month: 'Feb', detections: 15, normal: 102 },
  { month: 'Mar', detections: 18, normal: 115 },
  { month: 'Apr', detections: 14, normal: 120 },
  { month: 'May', detections: 16, normal: 128 },
  { month: 'Jun', detections: 14, normal: 135 },
];

const modelConfidence = [
  { range: '90-100%', count: 856 },
  { range: '80-90%', count: 245 },
  { range: '70-80%', count: 98 },
  { range: '60-70%', count: 48 },
];

const distributionData = [
  { name: 'Seizure', value: 89, color: '#EF4444' },
  { name: 'Normal', value: 1158, color: '#10B981' },
];

const recentAnalyses = [
  {
    id: 'PT-1247',
    date: '2026-03-15 09:23',
    duration: '45 min',
    status: 'Seizure Detected',
    confidence: '94%',
    statusColor: 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200',
  },
  {
    id: 'PT-1246',
    date: '2026-03-15 08:15',
    duration: '60 min',
    status: 'Normal',
    confidence: '98%',
    statusColor: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200',
  },
  {
    id: 'PT-1245',
    date: '2026-03-14 22:45',
    duration: '30 min',
    status: 'Normal',
    confidence: '96%',
    statusColor: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200',
  },
  {
    id: 'PT-1244',
    date: '2026-03-14 18:30',
    duration: '40 min',
    status: 'Seizure Detected',
    confidence: '91%',
    statusColor: 'bg-red-100 dark:bg-red-900 text-red-800 dark:text-red-200',
  },
  {
    id: 'PT-1243',
    date: '2026-03-14 14:20',
    duration: '55 min',
    status: 'Normal',
    confidence: '99%',
    statusColor: 'bg-green-100 dark:bg-green-900 text-green-800 dark:text-green-200',
  },
];

export default function Dashboard() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Dashboard</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Overview of neonatal seizure detection analytics
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat) => (
          <Card key={stat.title} className="dark:bg-slate-800 dark:border-gray-700">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div className={`p-3 rounded-lg ${stat.bgColor}`}>
                  <stat.icon className={`h-6 w-6 ${stat.color}`} />
                </div>
                <span className="text-xs font-medium text-green-600 dark:text-green-400">
                  {stat.change}
                </span>
              </div>
              <div className="mt-4">
                <p className="text-2xl font-bold text-gray-900 dark:text-white">{stat.value}</p>
                <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">{stat.title}</p>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts Row */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Seizure Detection Trends */}
        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-gray-900 dark:text-white">Seizure Detection Trends</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <AreaChart data={seizureTrends}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-gray-300 dark:stroke-gray-700" />
                <XAxis dataKey="month" className="text-gray-600 dark:text-gray-400" />
                <YAxis className="text-gray-600 dark:text-gray-400" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                  }}
                />
                <Area
                  type="monotone"
                  dataKey="detections"
                  stackId="1"
                  stroke="#EF4444"
                  fill="#EF4444"
                  fillOpacity={0.6}
                  name="Seizure Detections"
                />
                <Area
                  type="monotone"
                  dataKey="normal"
                  stackId="1"
                  stroke="#10B981"
                  fill="#10B981"
                  fillOpacity={0.6}
                  name="Normal"
                />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {/* Model Confidence Distribution */}
        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-gray-900 dark:text-white">Model Confidence Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={modelConfidence}>
                <CartesianGrid strokeDasharray="3 3" className="stroke-gray-300 dark:stroke-gray-700" />
                <XAxis dataKey="range" className="text-gray-600 dark:text-gray-400" />
                <YAxis className="text-gray-600 dark:text-gray-400" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: 'rgba(255, 255, 255, 0.95)',
                    border: '1px solid #e5e7eb',
                    borderRadius: '8px',
                  }}
                />
                <Bar dataKey="count" fill="#3B82F6" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Analysis Distribution and Recent Analyses */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Analysis Distribution */}
        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-gray-900 dark:text-white">Analysis Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={250}>
              <PieChart>
                <Pie
                  data={distributionData}
                  cx="50%"
                  cy="50%"
                  labelLine={false}
                  label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                  outerRadius={80}
                  fill="#8884d8"
                  dataKey="value"
                >
                  {distributionData.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={entry.color} />
                  ))}
                </Pie>
                <Tooltip />
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-red-500" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">Seizure</span>
                </div>
                <span className="text-sm font-medium text-gray-900 dark:text-white">89</span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-3 h-3 rounded-full bg-green-500" />
                  <span className="text-sm text-gray-600 dark:text-gray-400">Normal</span>
                </div>
                <span className="text-sm font-medium text-gray-900 dark:text-white">1,158</span>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Recent Patient Analysis */}
        <Card className="lg:col-span-2 dark:bg-slate-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-gray-900 dark:text-white">Recent Patient Analysis</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {recentAnalyses.map((analysis) => (
                <div
                  key={analysis.id}
                  className="flex items-center justify-between p-4 bg-gray-50 dark:bg-slate-900 rounded-lg border border-gray-200 dark:border-gray-700"
                >
                  <div className="flex-1">
                    <div className="flex items-center gap-3 mb-2">
                      <p className="font-semibold text-gray-900 dark:text-white">{analysis.id}</p>
                      <Badge className={analysis.statusColor}>{analysis.status}</Badge>
                    </div>
                    <div className="flex items-center gap-4 text-sm text-gray-600 dark:text-gray-400">
                      <span className="flex items-center gap-1">
                        <Clock className="h-3 w-3" />
                        {analysis.date}
                      </span>
                      <span>Duration: {analysis.duration}</span>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm text-gray-600 dark:text-gray-400">Confidence</p>
                    <p className="text-lg font-bold text-gray-900 dark:text-white">{analysis.confidence}</p>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
