import { useState } from 'react';
import { Upload, FileText, CheckCircle, AlertCircle } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '../components/ui/card';
import { Input } from '../components/ui/input';
import { Label } from '../components/ui/label';
import { Button } from '../components/ui/button';
import { Progress } from '../components/ui/progress';

export default function UploadEEG() {
  const [file, setFile] = useState<File | null>(null);
  const [uploading, setUploading] = useState(false);
  const [uploadProgress, setUploadProgress] = useState(0);
  const [uploadComplete, setUploadComplete] = useState(false);
  const [patientId, setPatientId] = useState('');
  const [recordingDate, setRecordingDate] = useState('');
  const [dragActive, setDragActive] = useState(false);

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === 'dragenter' || e.type === 'dragover') {
      setDragActive(true);
    } else if (e.type === 'dragleave') {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      setFile(e.dataTransfer.files[0]);
    }
  };

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      setFile(e.target.files[0]);
    }
  };

  const handleUpload = () => {
    if (!file || !patientId || !recordingDate) return;
    
    setUploading(true);
    setUploadProgress(0);

    // Simulate upload progress
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setUploading(false);
          setUploadComplete(true);
          return 100;
        }
        return prev + 10;
      });
    }, 300);
  };

  const resetForm = () => {
    setFile(null);
    setPatientId('');
    setRecordingDate('');
    setUploadProgress(0);
    setUploadComplete(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-3xl font-bold text-gray-900 dark:text-white">Upload EEG Recording</h1>
        <p className="text-gray-600 dark:text-gray-400 mt-1">
          Upload EDF format EEG recordings for AI-powered seizure detection
        </p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Upload Form */}
        <Card className="dark:bg-slate-800 dark:border-gray-700">
          <CardHeader>
            <CardTitle className="text-gray-900 dark:text-white">EEG File Upload</CardTitle>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Drag and Drop Area */}
            <div
              onDragEnter={handleDrag}
              onDragLeave={handleDrag}
              onDragOver={handleDrag}
              onDrop={handleDrop}
              className={`border-2 border-dashed rounded-xl p-8 text-center transition-colors ${
                dragActive
                  ? 'border-blue-500 dark:border-teal-400 bg-blue-50 dark:bg-blue-900/20'
                  : 'border-gray-300 dark:border-gray-600'
              }`}
            >
              {file ? (
                <div className="space-y-3">
                  <CheckCircle className="h-12 w-12 text-green-600 dark:text-green-400 mx-auto" />
                  <div>
                    <p className="font-semibold text-gray-900 dark:text-white">{file.name}</p>
                    <p className="text-sm text-gray-600 dark:text-gray-400">
                      {(file.size / 1024 / 1024).toFixed(2)} MB
                    </p>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => setFile(null)}
                    className="dark:border-gray-600"
                  >
                    Change File
                  </Button>
                </div>
              ) : (
                <div className="space-y-3">
                  <Upload className="h-12 w-12 text-gray-400 mx-auto" />
                  <div>
                    <p className="font-semibold text-gray-900 dark:text-white">
                      Drag and drop your EEG file here
                    </p>
                    <p className="text-sm text-gray-600 dark:text-gray-400 mt-1">or</p>
                  </div>
                  <label htmlFor="file-upload">
                    <Button variant="outline" asChild className="dark:border-gray-600">
                      <span className="cursor-pointer">Browse Files</span>
                    </Button>
                  </label>
                  <input
                    id="file-upload"
                    type="file"
                    accept=".edf"
                    onChange={handleFileChange}
                    className="hidden"
                  />
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-2">
                    Supported format: EDF (European Data Format)
                  </p>
                </div>
              )}
            </div>

            {/* Patient Information */}
            <div className="space-y-4">
              <div>
                <Label htmlFor="patientId" className="text-gray-700 dark:text-gray-300">
                  Patient ID
                </Label>
                <Input
                  id="patientId"
                  type="text"
                  value={patientId}
                  onChange={(e) => setPatientId(e.target.value)}
                  placeholder="PT-1234"
                  className="mt-1 dark:bg-slate-900 dark:border-gray-700"
                />
              </div>

              <div>
                <Label htmlFor="recordingDate" className="text-gray-700 dark:text-gray-300">
                  Recording Date
                </Label>
                <Input
                  id="recordingDate"
                  type="datetime-local"
                  value={recordingDate}
                  onChange={(e) => setRecordingDate(e.target.value)}
                  className="mt-1 dark:bg-slate-900 dark:border-gray-700"
                />
              </div>
            </div>

            {/* Upload Progress */}
            {uploading && (
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="text-gray-600 dark:text-gray-400">Uploading...</span>
                  <span className="font-semibold text-gray-900 dark:text-white">{uploadProgress}%</span>
                </div>
                <Progress value={uploadProgress} className="h-2" />
              </div>
            )}

            {/* Success Message */}
            {uploadComplete && (
              <div className="p-4 bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg">
                <div className="flex items-center gap-2 text-green-800 dark:text-green-200">
                  <CheckCircle className="h-5 w-5" />
                  <p className="font-semibold">Upload Successful!</p>
                </div>
                <p className="text-sm text-green-700 dark:text-green-300 mt-1">
                  EEG recording has been uploaded and queued for analysis.
                </p>
              </div>
            )}

            {/* Action Buttons */}
            <div className="flex gap-3">
              {uploadComplete ? (
                <Button
                  onClick={resetForm}
                  className="flex-1 bg-blue-600 hover:bg-blue-700 dark:bg-teal-600 dark:hover:bg-teal-700 text-white"
                >
                  Upload Another File
                </Button>
              ) : (
                <>
                  <Button
                    onClick={handleUpload}
                    disabled={!file || !patientId || !recordingDate || uploading}
                    className="flex-1 bg-blue-600 hover:bg-blue-700 dark:bg-teal-600 dark:hover:bg-teal-700 text-white disabled:opacity-50"
                  >
                    {uploading ? 'Uploading...' : 'Upload & Analyze'}
                  </Button>
                  <Button
                    variant="outline"
                    onClick={resetForm}
                    disabled={uploading}
                    className="dark:border-gray-600"
                  >
                    Reset
                  </Button>
                </>
              )}
            </div>
          </CardContent>
        </Card>

        {/* Information Panel */}
        <div className="space-y-6">
          {/* EEG Waveform Visualization */}
          <Card className="dark:bg-slate-800 dark:border-gray-700">
            <CardHeader>
              <CardTitle className="text-gray-900 dark:text-white">EEG Signal Preview</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="bg-gray-900 dark:bg-black rounded-lg p-6 h-64 flex items-center justify-center relative overflow-hidden">
                {/* Simulated EEG waveform */}
                <svg className="w-full h-full" viewBox="0 0 400 200">
                  <path
                    d="M 0 100 Q 20 80, 40 100 T 80 100 Q 100 120, 120 100 T 160 100 Q 180 85, 200 100 T 240 100 Q 260 115, 280 100 T 320 100 Q 340 90, 360 100 T 400 100"
                    stroke="#10B981"
                    strokeWidth="2"
                    fill="none"
                    opacity="0.7"
                  />
                  <path
                    d="M 0 120 Q 20 105, 40 120 T 80 120 Q 100 135, 120 120 T 160 120 Q 180 110, 200 120 T 240 120 Q 260 130, 280 120 T 320 120 Q 340 115, 360 120 T 400 120"
                    stroke="#3B82F6"
                    strokeWidth="2"
                    fill="none"
                    opacity="0.7"
                  />
                  <path
                    d="M 0 80 Q 20 70, 40 80 T 80 80 Q 100 95, 120 80 T 160 80 Q 180 75, 200 80 T 240 80 Q 260 88, 280 80 T 320 80 Q 340 77, 360 80 T 400 80"
                    stroke="#14B8A6"
                    strokeWidth="2"
                    fill="none"
                    opacity="0.7"
                  />
                </svg>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mt-4">
                Real-time EEG waveform preview will appear here after upload
              </p>
            </CardContent>
          </Card>

          {/* Upload Guidelines */}
          <Card className="dark:bg-slate-800 dark:border-gray-700">
            <CardHeader>
              <CardTitle className="text-gray-900 dark:text-white">Upload Guidelines</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-start gap-3">
                <FileText className="h-5 w-5 text-blue-600 dark:text-teal-400 mt-0.5" />
                <div>
                  <p className="font-semibold text-gray-900 dark:text-white text-sm">File Format</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Only EDF (European Data Format) files are supported
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-blue-600 dark:text-teal-400 mt-0.5" />
                <div>
                  <p className="font-semibold text-gray-900 dark:text-white text-sm">Recording Quality</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Ensure recordings are of good quality with minimal artifacts
                  </p>
                </div>
              </div>
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-blue-600 dark:text-teal-400 mt-0.5" />
                <div>
                  <p className="font-semibold text-gray-900 dark:text-white text-sm">Data Privacy</p>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    All uploads are encrypted and HIPAA compliant
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
