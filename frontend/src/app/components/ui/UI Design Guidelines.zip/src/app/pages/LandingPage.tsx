import { Link } from 'react-router';
import { useTheme } from '../context/ThemeContext';
import { Moon, Sun, Activity, Brain, Shield, Zap, Upload, BarChart3, FileText } from 'lucide-react';
import { ImageWithFallback } from '../components/figma/ImageWithFallback';
import { Button } from '../components/ui/button';

export default function LandingPage() {
  const { theme, toggleTheme } = useTheme();

  return (
    <div className="min-h-screen bg-white dark:bg-slate-900">
      {/* Navigation */}
      <nav className="border-b border-gray-200 dark:border-gray-800">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center gap-2">
              <Brain className="h-8 w-8 text-blue-600 dark:text-teal-400" />
              <span className="text-xl font-semibold text-gray-900 dark:text-white">NeuroXAI</span>
            </div>
            <div className="flex items-center gap-4">
              <button
                onClick={toggleTheme}
                className="p-2 rounded-lg hover:bg-gray-100 dark:hover:bg-gray-800 transition-colors"
              >
                {theme === 'light' ? (
                  <Moon className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                ) : (
                  <Sun className="h-5 w-5 text-gray-600 dark:text-gray-400" />
                )}
              </button>
              <Link to="/signin">
                <Button variant="ghost" className="text-gray-700 dark:text-gray-300">Sign In</Button>
              </Link>
              <Link to="/signup">
                <Button className="bg-blue-600 hover:bg-blue-700 text-white dark:bg-teal-600 dark:hover:bg-teal-700">
                  Get Started
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div>
              <h1 className="text-5xl font-bold text-gray-900 dark:text-white mb-6">
                AI-Powered Neonatal Seizure Detection
              </h1>
              <p className="text-xl text-gray-600 dark:text-gray-300 mb-8">
                NeuroXAI helps doctors detect seizures in newborns early using advanced EEG analysis and explainable artificial intelligence. Providing clinical decision support when it matters most.
              </p>
              <div className="flex gap-4">
                <Link to="/signup">
                  <Button size="lg" className="bg-blue-600 hover:bg-blue-700 text-white dark:bg-teal-600 dark:hover:bg-teal-700">
                    Get Started
                  </Button>
                </Link>
                <Link to="/signin">
                  <Button size="lg" variant="outline" className="border-gray-300 dark:border-gray-600">
                    Sign In
                  </Button>
                </Link>
              </div>
            </div>
            <div className="relative">
              <ImageWithFallback
                src="https://images.unsplash.com/photo-1766299893052-107053bc92a1?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxuZXdib3JuJTIwYmFieSUyMGNhcmUlMjBob3NwaXRhbHxlbnwxfHx8fDE3NzM1OTgyOTl8MA&ixlib=rb-4.1.0&q=80&w=1080"
                alt="Neonatal care"
                className="rounded-2xl shadow-2xl"
              />
            </div>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-slate-800">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">How It Works</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">Simple, fast, and accurate seizure detection</p>
          </div>
          <div className="grid md:grid-cols-3 gap-8">
            <div className="bg-white dark:bg-slate-900 p-8 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-blue-100 dark:bg-blue-900 rounded-lg flex items-center justify-center mb-4">
                <Upload className="h-6 w-6 text-blue-600 dark:text-blue-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Upload EEG Recording</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Upload EDF format EEG recordings from neonatal patients with secure, HIPAA-compliant processing.
              </p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-8 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-teal-100 dark:bg-teal-900 rounded-lg flex items-center justify-center mb-4">
                <Activity className="h-6 w-6 text-teal-600 dark:text-teal-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">AI Analysis</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Our advanced AI model analyzes brain signals to detect seizure patterns with high accuracy.
              </p>
            </div>
            <div className="bg-white dark:bg-slate-900 p-8 rounded-xl shadow-lg">
              <div className="w-12 h-12 bg-purple-100 dark:bg-purple-900 rounded-lg flex items-center justify-center mb-4">
                <BarChart3 className="h-6 w-6 text-purple-600 dark:text-purple-400" />
              </div>
              <h3 className="text-xl font-semibold text-gray-900 dark:text-white mb-3">Explainable Insights</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Get detailed explanations of AI predictions with visualizations showing which signals influenced the diagnosis.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Benefits */}
      <section className="py-20 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="text-center mb-16">
            <h2 className="text-4xl font-bold text-gray-900 dark:text-white mb-4">Benefits</h2>
            <p className="text-xl text-gray-600 dark:text-gray-300">Transforming neonatal care with AI</p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6">
            <div className="p-6 border border-gray-200 dark:border-gray-700 rounded-xl">
              <Zap className="h-8 w-8 text-green-600 dark:text-green-400 mb-3" />
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Early Seizure Detection</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Identify seizures quickly to enable faster intervention and better outcomes.
              </p>
            </div>
            <div className="p-6 border border-gray-200 dark:border-gray-700 rounded-xl">
              <Brain className="h-8 w-8 text-blue-600 dark:text-blue-400 mb-3" />
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">AI-Assisted Diagnosis</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Reduce diagnostic burden with intelligent analysis that augments clinical expertise.
              </p>
            </div>
            <div className="p-6 border border-gray-200 dark:border-gray-700 rounded-xl">
              <FileText className="h-8 w-8 text-purple-600 dark:text-purple-400 mb-3" />
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Explainable Analysis</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Understand AI decisions with transparent visualizations of signal patterns.
              </p>
            </div>
            <div className="p-6 border border-gray-200 dark:border-gray-700 rounded-xl">
              <Shield className="h-8 w-8 text-teal-600 dark:text-teal-400 mb-3" />
              <h3 className="font-semibold text-gray-900 dark:text-white mb-2">Clinical Decision Support</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Make informed decisions with confidence scores and detailed analysis reports.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-gray-200 dark:border-gray-800 py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto text-center">
          <div className="flex items-center justify-center gap-2 mb-4">
            <Brain className="h-6 w-6 text-blue-600 dark:text-teal-400" />
            <span className="text-lg font-semibold text-gray-900 dark:text-white">NeuroXAI</span>
          </div>
          <p className="text-gray-600 dark:text-gray-400">
            AI-Powered Neonatal Seizure Detection Platform
          </p>
          <p className="text-sm text-gray-500 dark:text-gray-500 mt-4">
            © 2026 NeuroXAI. All rights reserved.
          </p>
        </div>
      </footer>
    </div>
  );
}
